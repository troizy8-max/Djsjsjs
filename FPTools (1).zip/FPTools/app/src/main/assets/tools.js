(function () {
  if (window.__fpt) return; window.__fpt = true;
  var K = 'fpt_cfg';
  var cfg = Object.assign({ raise: true, hours: 4, notify: true, last: 0 }, JSON.parse(localStorage.getItem(K) || '{}'));
  function save() { localStorage.setItem(K, JSON.stringify(cfg)); }
  function app() { try { return JSON.parse(document.body.getAttribute('data-app-data')) || {}; } catch (e) { return {}; } }
  var st;
  function log(t) { if (st) st.textContent = t; }

  async function post(url, pairs) {
    var d = app(), b = new URLSearchParams();
    pairs.forEach(function (p) { b.append(p[0], p[1]); });
    b.append('csrf_token', d['csrf-token'] || '');
    var r = await fetch(url, { method: 'POST', credentials: 'include', body: b,
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' } });
    return r.text();
  }
  async function getDoc(url) {
    var h = await (await fetch(url, { credentials: 'include' })).text();
    return new DOMParser().parseFromString(h, 'text/html');
  }

  async function raiseAll() {
    var uid = app().userId;
    if (!uid) { log('Войдите в аккаунт FunPay'); return; }
    log('Поднимаю лоты…');
    var prof = await getDoc('/users/' + uid + '/');
    var nodes = [];
    prof.querySelectorAll('.offer-list-title a').forEach(function (a) {
      var m = (a.getAttribute('href') || '').match(/lots\/(\d+)/);
      if (m && nodes.indexOf(m[1]) < 0) nodes.push(m[1]);
    });
    var ok = 0, msgs = [];
    for (var i = 0; i < nodes.length; i++) {
      try {
        var doc = await getDoc('/lots/' + nodes[i] + '/trade');
        var btn = doc.querySelector('.js-lot-raise');
        if (!btn) continue;
        var game = btn.getAttribute('data-game');
        var t = await post('/lots/raise', [['game_id', game], ['node_id', nodes[i]]]);
        var j = {}; try { j = JSON.parse(t); } catch (e) {}
        if (j.modal) {
          var md = new DOMParser().parseFromString(j.modal, 'text/html');
          var pairs = [['game_id', game], ['node_id', nodes[i]]];
          md.querySelectorAll('input[type=checkbox]').forEach(function (c) { pairs.push(['node_ids[]', c.value]); });
          t = await post('/lots/raise', pairs);
          try { j = JSON.parse(t); } catch (e) {}
        }
        if (j.msg) msgs.push(j.msg.replace(/<[^>]+>/g, '')); 
        ok++;
      } catch (e) { msgs.push('ошибка ' + nodes[i]); }
      await new Promise(function (r) { setTimeout(r, 1500); });
    }
    cfg.last = Date.now(); save();
    log('Готово (' + ok + '/' + nodes.length + '). ' + (msgs[0] || ''));
    if (cfg.notify && window.AndroidBridge) AndroidBridge.notify('FP Tools', 'Лоты обработаны: ' + ok + '/' + nodes.length + '. ' + (msgs[0] || ''));
  }

  var lastBadge = null;
  async function checkChat() {
    try {
      var doc = await getDoc('/');
      var b = doc.querySelector('.menu-item-chat .badge, .badge-chat');
      var n = b ? parseInt(b.textContent, 10) || 0 : 0;
      if (lastBadge !== null && n > lastBadge && cfg.notify && window.AndroidBridge)
        AndroidBridge.notify('FunPay', 'Новых сообщений: ' + n);
      lastBadge = n;
    } catch (e) {}
  }

  function tick() {
    if (cfg.raise && Date.now() - cfg.last > cfg.hours * 3600000) raiseAll();
  }

  function ui() {
    var fab = document.createElement('div');
    fab.textContent = 'FP';
    fab.style.cssText = 'position:fixed;right:10px;bottom:80px;z-index:99999;width:44px;height:44px;border-radius:22px;background:#e8472b;color:#fff;font:bold 15px sans-serif;display:flex;align-items:center;justify-content:center;opacity:.85';
    var p = document.createElement('div');
    p.style.cssText = 'position:fixed;right:10px;bottom:132px;z-index:99999;width:250px;padding:12px;border-radius:10px;background:#222;color:#fff;font:14px sans-serif;display:none';
    p.innerHTML = '<label><input type="checkbox" id="fpr"> Автоподнятие</label><br>' +
      'Каждые <input id="fph" type="number" min="1" max="24" style="width:50px"> ч<br>' +
      '<label><input type="checkbox" id="fpn"> Уведомления</label><br>' +
      '<button id="fpgo" style="margin-top:8px;padding:6px 10px">Поднять сейчас</button>' +
      '<div id="fps" style="margin-top:8px;font-size:12px;color:#bbb"></div>';
    document.body.appendChild(fab); document.body.appendChild(p);
    var $ = function (i) { return p.querySelector('#' + i); };
    st = $('fps');
    $('fpr').checked = cfg.raise; $('fph').value = cfg.hours; $('fpn').checked = cfg.notify;
    $('fpr').onchange = function () { cfg.raise = this.checked; save(); };
    $('fph').onchange = function () { cfg.hours = Math.max(1, +this.value || 4); save(); };
    $('fpn').onchange = function () { cfg.notify = this.checked; save(); };
    $('fpgo').onclick = raiseAll;
    fab.onclick = function () { p.style.display = p.style.display === 'none' ? 'block' : 'none'; };
  }

  function start() { ui(); tick(); setInterval(tick, 60000); checkChat(); setInterval(checkChat, 60000); }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
