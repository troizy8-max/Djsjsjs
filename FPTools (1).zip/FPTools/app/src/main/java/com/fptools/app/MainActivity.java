package com.fptools.app;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;

public class MainActivity extends Activity {
    static final String CH_ALERT = "alerts", CH_SERVICE = "service";
    WebView web;
    String toolsJs = "";

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Уведомления FunPay", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(CH_SERVICE, "Фоновая работа", NotificationManager.IMPORTANCE_LOW));
    }

    class Bridge {
        @JavascriptInterface
        public void notify(String title, String text) {
            Notification n = new Notification.Builder(MainActivity.this, CH_ALERT)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title).setContentText(text).setAutoCancel(true).build();
            getSystemService(NotificationManager.class).notify((int) (System.currentTimeMillis() % 100000), n);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ensureChannels(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        try (InputStream in = getAssets().open("tools.js")) {
            toolsJs = new String(in.readAllBytes(), "UTF-8");
        } catch (Exception e) { toolsJs = ""; }

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, Bitmap f) {
                if (url != null && url.contains("funpay.com")) v.evaluateJavascript(toolsJs, null);
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                if (url != null && url.contains("funpay.com")) v.evaluateJavascript(toolsJs, null);
            }
        });
        startForegroundService(new Intent(this, KeepAliveService.class));
        web.loadUrl("https://funpay.com/");
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
