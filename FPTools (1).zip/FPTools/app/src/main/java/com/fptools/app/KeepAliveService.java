package com.fptools.app;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class KeepAliveService extends Service {
    PowerManager.WakeLock wl;

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        MainActivity.ensureChannels(this);
        Notification n = new Notification.Builder(this, MainActivity.CH_SERVICE)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("FP Tools работает")
                .setContentText("Автоподнятие и уведомления активны").build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(1, n);
        if (wl == null) {
            wl = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fptools:keep");
            wl.acquire();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
