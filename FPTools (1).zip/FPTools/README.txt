FP Tools (Android) — как получить APK

1. Создай аккаунт на github.com и новый репозиторий (New repository).
2. Загрузи ВСЕ файлы из архива (Add file -> Upload files). Папки app, .github тоже.
   Если .github не загрузилась: Add file -> Create new file, имя
   .github/workflows/build.yml и вставь туда содержимое этого файла.
3. Открой вкладку Actions -> Build APK -> дождись зелёной галочки (3-6 минут).
   Если не запустилось: Run workflow.
4. Внутри запуска внизу "Artifacts" -> FPTools-apk -> скачай, распакуй, установи app-debug.apk.
5. Разреши установку из неизвестных источников и уведомления.

В приложении: войди в FunPay, справа появится кнопка "FP" с настройками.
